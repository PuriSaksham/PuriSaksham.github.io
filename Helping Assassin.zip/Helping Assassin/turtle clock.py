loop = True
lloop = True
import datetime, turtle, time, turtle

while loop == True:
    hi = turtle.Turtle()
    turtle.shape("turtle")
    turtle.color("black")
    turtle.speed(1000000)
    turtle.degrees(360)
    currenttime = datetime.datetime.now()
    print (currenttime.hour)
    print (currenttime.minute)

    turtle.setheading(90)


    for x in range(12):
        
        turtle.penup()
        turtle.goto(0,0)
        turtle.right(30)
        turtle.forward(200)
        turtle.pendown()
        turtle.forward(20)
        turtle.penup()
        turtle.forward(10)
        turtle.stamp()
    update = currenttime.minute
   
    while lloop == True:
        currenttime = datetime.datetime.now()
        print (currenttime.minute)
        hi.penup()
        hi.goto(0,0)
        hi.setheading(90)

        hi.right(0.5*(60*currenttime.hour + currenttime.minute))
        hi.pendown()
        hi.forward(150)


        hi.goto(0,0)
        hi.setheading(90)
        hi.right(currenttime.minute*360/60)
        hi.pendown()
        hi.forward(200)
        hi.hideturtle()
        if update != currenttime.minute:
            hi.clear()
            hi.showturtle()
            update = currenttime.minute
   
